print(int(3.14))
print(int(10+j5))
print(int(True))#=1
print(int(False))#=0
print(int("4.22"))
print(int("4"))

# float()used to convert
# print(float(3.14))
# print(float(10+5j))
# print(float(True))#1.0
# print(float(False))#0.0
# print(float("4.22"))#4.22
# print(float("4"))

#bool()is used to convert
# print(bool(0))
# print(bool(15))
# print(bool(3.14))
# print(bool(0.0))
# print(bool(1+2j))
# print(bool(0+0j))
# print(bool(-1))
# print(bool(False))
# print(bool(True))
# print(bool(" "))