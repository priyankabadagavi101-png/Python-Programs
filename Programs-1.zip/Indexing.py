name=   "priyankabadagavi"
#indexing=012345678910
print(name[0])
print(name[1])
print(name[-1])
#print(name[15])Error string index out of range
print(name[0:5])
print(name[1:])
print(name[:5])
print(name[:])
print(name[1:9:2])
print(name[::-1])