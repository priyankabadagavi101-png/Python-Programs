# print('Subjects Marks :')

phy = 50
chem = 60
math = 70

print("physics ={}  chemistry={}  Math={} ".format(phy, chem, math))
print("physics ={0}  chemistry={1}  Math={2} ".format(phy, chem, math))
print("physics ={x}  chemistry={y}  Math={z} ".format(x=phy, y=chem, z=math))

total = phy + chem + math

print("Total Marks", f"{total}")
print("Ro5ll No=", "7".zfill(4))

#conditional statement 
#simple if
#WAPto accept one single digit and check the entered number is positive, negative, zero.
N=int(input("Enter single digit:"))
if N>0:
    print("Entered number is positive")
if N<0:
    print("Negative number")
if N==0:
    print("Zero")

#WAP to accept days and check the working day or weekend
day =input("Enter Day:")
if day == "Saturday" or day == "sunday" or day == 'SATURDAY' or day =='sunday':
    print("Weekend")
else:
    print("Working day")


#1. rstrip() ==> To remove spaces at right hand side
#2. lstrip() ==> To remove spaces at left hand side
#3. strip()  ==> To remove spaces both sides

programming = input("Enter your programming Name: ")
p_name = programming.strip()

if p_name == "Python":
    print(p_name)

elif p_name == "Java":
    print(p_name)

elif p_name == "Cpp":
    print(p_name)

else:
    print("Wrong programming name")

a=50
b=30
c=20
d=10
print((a+b)*c/d)
print((a-b)*(c/d))
print(a+(b*c)/d)