Height=5
inch=Height*12
cm=inch*2.54
print("inch=",inch)
print("centimeter=",cm)